Grupo 8:
Augusto Peiter - 287685
Leonardo Holtz - 287702
Marcelo Audibert - 283055